from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DerivedVariables:
    visit_id: str

    dv_age_bucket: str
    dv_distance_priority: str
    dv_near_priority: str
    dv_symptom_risk_level: str
    dv_medical_risk_level: str
    dv_stability_level: str
    dv_ar_lenso_mismatch_level_RE: str
    dv_ar_lenso_mismatch_level_LE: str
    dv_start_source_policy: str

    dv_start_rx_RE_sph: float | None
    dv_start_rx_RE_cyl: float | None
    dv_start_rx_RE_axis: float | None
    dv_start_rx_LE_sph: float | None
    dv_start_rx_LE_cyl: float | None
    dv_start_rx_LE_axis: float | None

    dv_add_expected: str
    dv_target_distance_va: str
    dv_endpoint_bias_policy: str
    dv_step_size_policy: str

    dv_max_delta_from_start_sph: float
    dv_max_delta_from_ar_sph: float

    dv_axis_tolerance_deg: float
    dv_axis_tolerance_deg_RE: float
    dv_axis_tolerance_deg_LE: float
    dv_cyl_tolerance_D: float

    dv_requires_optom_review: bool
    dv_anomaly_watch: bool

    dv_expected_convergence_time: str
    dv_branching_guardrails: str
    dv_confidence_requirement: str

    dv_fogging_policy: str
    dv_fogging_amount_D: float
    dv_fogging_clearance_mode: str
    dv_fogging_required_confirmation: str

    dv_axis_step_policy: str
    dv_duochrome_max_flips: int
    dv_near_test_required: bool

    # FSM v3.1 additions
    dv_accommodation_level: str = "Unknown"
    dv_fogging_required: bool = False
    dv_fogging_stop_at_target_va: bool = True

    # FSM v2.3 additions (defaults prevent breaking existing scripts)

    dv_jcc_axis_same_required: int = 2
    dv_jcc_axis_max_flips: int = 3
    dv_quick_axis_search_RE: bool = False
    dv_quick_axis_search_LE: bool = False
    dv_axis_source_used_RE: str = ""
    dv_axis_source_used_LE: str = ""
    dv_axis_cyl_magnitude_for_lane_RE: float = 0.0
    dv_axis_cyl_magnitude_for_lane_LE: float = 0.0
    dv_axis_cyl_magnitude_for_tolerance_RE: float = 0.0
    dv_axis_cyl_magnitude_for_tolerance_LE: float = 0.0
    dv_axis_is_near_cardinal_RE: bool = False
    dv_axis_is_near_cardinal_LE: bool = False
    dv_axis_lane_id_RE: str = ""
    dv_axis_lane_id_LE: str = ""
    dv_axis_lane_name_RE: str = ""
    dv_axis_lane_name_LE: str = ""
    dv_axis_step_sequence_RE: str = ""
    dv_axis_step_sequence_LE: str = ""
    dv_axis_confidence_label_RE: str = ""
    dv_axis_confidence_label_LE: str = ""
    dv_axis_selection_reason_RE: str = ""
    dv_axis_selection_reason_LE: str = ""

    dv_near_start_add_r: float = 0.0
    dv_near_start_add_l: float = 0.0
    dv_near_binoc_step_D: float = 0.25
    dv_near_binoc_max_plus_steps: int = 4
    dv_near_binoc_max_minus_steps: int = 4
